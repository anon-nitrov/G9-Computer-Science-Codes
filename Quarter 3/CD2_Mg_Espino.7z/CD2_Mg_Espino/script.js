function changeImage1 ()  {
    Fullmetal_Alchemist_Brotherhood.src='https://www.pixelstalk.net/wp-content/uploads/2016/07/Fullmetal-Alchemist-Brotherhood-Desktop-Wallpaper.jpg';
    document.getElementById('image1').innerHTML = "Fullmetal Alchemist: Brotherhood" + "<br />" + "Score: 9.14" + "<br />" + "Status: Finished Airing";
}	
	
function changeImage2 () {
    Spy_x_Family.src='https://m.media-amazon.com/images/M/MV5BNDQ0MTRlMzItMDIyMi00YWFiLThjMjctOGYxZGZkNmY4ZDY1XkEyXkFqcGdeQXVyMTE2OTU3MTQ2._V1_.jpg';
    document.getElementById('image2').innerHTML ="Spy x Family" + "<br />" + "Score: 9.09" + "<br />" + "Status: Currently Airing";
}

function changeImage3 () {
    Shingeki_no_Kyojin_Season_3_Part_2.src='https://www.teahub.io/photos/full/12-125957_attack-on-titan-wallpaper-attack-on-titan-season.jpg';
    document.getElementById('image3').innerHTML = "Shingeki no Kyojin Season 3 Part 2" + "<br />" + "Score: 9.08" + "<br />" + "Finished Airing";
}

function changeImage4 () {
    Steins_Gate.src='https://2.bp.blogspot.com/-VXvWH8cspyA/Wj5tmBu9pXI/AAAAAAAADEg/iJAdFrfKu4kHWGsFZ-YvVVYGvAUql6oAgCLcBGAs/s1600/Steins%252CGate%2BAnime.png';
    document.getElementById('image4').innerHTML = "Steins;Gate" + "<br />" + "Score: 9.08" + "<br />" + "Status: Finished Airing";
}

function changeImage5 () {
    image5.src='http://www.checkin.ph/webmag/wp-content/uploads/2021/08/PONYO.jpg';
    document.getElementById('image5').innerHTML = "Gintama°" + "<br />" + "Score: 9.08" + "<br />" + "Status: Finished Airing"
}